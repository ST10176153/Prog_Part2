﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;


// Ingredient class represents an ingridient with a name, quantity and unit of measurement, calories, and food group
class Ingredient
{
    //Properties of an ingredient
    public string Name { get; set; } //Name of the ingredient

    public double Quantity { get; set; } // Quantity of the ingredient 

    public string Unit { get; set; } //Unit of measurement for the quantity

    public int Calories { get; set; } //Number of calories in the ingredient

    public string FoodGroup { get; set; } //Food Group to which the ingredient belongs 

    //Constructor to initialize an ingredient
    public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
        Calories = calories;
        FoodGroup = foodGroup;
    }
}

// Recipe class represents a recipe
class Recipe
{

    //Properties of recipe
    public string Name { get; set; } // Name of the recipe
    private List<Ingredient> Ingredients { get; set; } // List of ingredients in the recipe
    private List<string> Steps { get; set; } // List of steps to prepare the recipe


    // Constructor initialises the recipe 
    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>(); // Initialize the list of ingredients
        Steps = new List<string>(); // Initialize the list of steps

    }

    // AddIngredient method adds a new ingredient to the recipe.
    public void AddIngredient(Ingredient ingredient)
    {
        Ingredients.Add(ingredient);

    }
    //AddStep Method adds a new step to the recipe
    public void AddStep(string step)
    {
        Steps.Add(step);
    }
    // DisplayRecipe method displays the recipe 
    public void DisplayRecipe()
    {
        Console.WriteLine($"\nRecipe: {Name}");

        // Display list of ingredients
        Console.WriteLine("\nIngredients:");
        foreach (var ingredient in Ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }

        // Display the list of Steps
        Console.WriteLine("\nSteps:");
        for (int i = 0; i < Steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}.{Steps[i]}");
        }
    }
    // CalculateTotalCalories method calculates the total calories of all ingredients in the recipe.
    public int CalculateTotalCalories()
    {
        int totalCalories = 0;
        foreach (var ingredient in Ingredients)
        {
            totalCalories +=ingredient.Calories;

        }
        return totalCalories;
    }
}    
       
    

class Program
{
    static List<Recipe> recipes = new List<Recipe>();
    

    // List to store all recipes entered by the user
    static void Main(string[] args)
    {
        Console.WriteLine("WELCOME TO THE RECIPE MANAGEMENT APPLICATION");
        Console.WriteLine("********************************************************************************");

        // Main applivation loop
        while (true)
        {
            //Display the Main Menu:
            Console.WriteLine("\nPlease choose an Option:");
            Console.WriteLine("1. Enter Recipe Details");
            Console.WriteLine("2. Display All Recipe");
            Console.WriteLine("3. Exit Menu");
            Console.Write("\nEnter your choice: ");

         string choice = Console.ReadLine();
            
            switch (choice)
            {
                case "1":
                    Console.Clear();
                    EnterRecipeDetails(); // Call method to enter recipe details

                    break;
                case "2":
                    Console.Clear();
                    DisplayAllRecipes(); // Call method to display all recipes

                    break;

                case "3":
                    Console.WriteLine("Exiting..."); // Exit the application
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter 1, 2, or 3.");
                    break;
            }
        }
    }

    static void EnterRecipeDetails()
    {
        //EnterRecipeDetails method prompts the user to enter details of a recipe and returns the created recipe.
        Console.WriteLine("Entering recipe details...");
        Console.Write("Enter recipe name: ");

        string name = Console.ReadLine();

        Recipe recipe = new Recipe(name);


        Console.Write("Enter number of ingredients: ");

        int numIngredients;

        // Validate input for the the number of ingredients
        while (!int.TryParse(Console.ReadLine(), out numIngredients) || numIngredients <=0)

        {
            Console.WriteLine("Invalid input. Please enter a positive integer.");
            Console.WriteLine("Enter number of ingredients: ");
        }
        for (int i = 0; i < numIngredients; i++)

        {
            Console.WriteLine($"Enter name of ingredient {i + 1}: ");

            string ingredientName = Console.ReadLine();


            Console.WriteLine($"Enter quantity of {ingredientName}: ");
            double quantity;

            while (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
            {

                Console.WriteLine("Invalid input. Please enter a positive number.");
                Console.WriteLine($"Enter quantity of {ingredientName}: ");
            }
            Console.WriteLine($"Enter unit of measurement for {ingredientName}: ");
            string unit = Console.ReadLine();

            Console.WriteLine($"Enter calories for {ingredientName}: ");
            int calories;
            while (!int.TryParse(Console.ReadLine(), out calories) || calories <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
                Console.WriteLine($"Enter calories for {ingredientName}: ");
            }

            Console.WriteLine($"Enter food group {ingredientName}: ");
            string foodGroup = Console.ReadLine();

            recipe.AddIngredient(new Ingredient(ingredientName, quantity, unit, calories, foodGroup));
        }
        recipes.Add(recipe);
        Console.WriteLine("Recipe details have been entered successfully.");
    }


    static void DisplayAllRecipes()
    {
        if (recipes.Count == 0)
       
        Console.WriteLine("List of all recipe:");
        foreach (var recipeItem in recipes.OrderBy(r => r.Name))
        {
            Console.WriteLine(recipeItem.Name);
        }
        Console.WriteLine("Enter the name of the recipe to display or type 'back' to return to the main menu: ");
        string recipeName = Console.ReadLine();
        if (recipeName.ToLower() == "back")
        {
            return;
        }
        Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
        if (recipe != null)
        {
            recipe.DisplayRecipe();
            int totalCalories = recipe.CalculateTotalCalories();
            Console.WriteLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: This recipe contains 300 calories!");
            }
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }
    }

}


       